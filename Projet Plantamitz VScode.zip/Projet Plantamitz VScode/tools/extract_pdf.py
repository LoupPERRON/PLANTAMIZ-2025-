import sys
from pathlib import Path

try:
    from pypdf import PdfReader
except Exception as e:
    print("ERROR: pypdf not installed. Please run: python -m pip install pypdf")
    sys.exit(2)

if len(sys.argv) < 3:
    print("Usage: python extract_pdf.py input.pdf output.txt")
    sys.exit(1)

input_path = Path(sys.argv[1])
output_path = Path(sys.argv[2])

if not input_path.exists():
    print(f"ERROR: input file not found: {input_path}")
    sys.exit(3)

try:
    reader = PdfReader(str(input_path))
    text_parts = []
    for i, page in enumerate(reader.pages):
        try:
            page_text = page.extract_text() or ""
        except Exception:
            page_text = ""
        text_parts.append(f"\n\n--- PAGE {i+1} ---\n\n")
        text_parts.append(page_text)

    all_text = "".join(text_parts)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(all_text, encoding='utf-8')
    print(f"WROTE: {output_path} ({len(all_text)} bytes)")
except Exception as e:
    print("ERROR: failed to extract PDF:", e)
    sys.exit(4)
