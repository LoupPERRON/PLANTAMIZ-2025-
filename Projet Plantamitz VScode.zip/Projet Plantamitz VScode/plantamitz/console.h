#pragma once

#include <windows.h>

void gotoligcol(int lig,int col);
void Color(int couleurDuTexte,int couleurDeFond);
void clear_screen();
