#pragma once

#include "board.h"

// allow_resume: 0 = always start new (ignore save), 1 = allow resume from save
void game_run(int allow_resume);
